package com.example.myquizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class TestActivity extends AppCompatActivity {
    private TextView questionText, scoreText;
    private Button optionA, optionB, optionC, optionD;

    private String[][] questions = {
            {"What is the capital of France?", "What is the largest ocean on Earth?"},
            {"What is the chemical symbol for water?", "What planet is closest to the sun?"},
            {"What is 5 + 7?", "What is the square root of 16?"},
            {"Which continent is the Sahara Desert in?", "Which river is the longest in the world?"}
    };

    private String[][][] options = {
            {{"Paris", "London", "Berlin", "Madrid"}, {"Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"}},
            {{"H2O", "CO2", "O2", "N2"}, {"Earth", "Mercury", "Venus", "Mars"}},
            {{"10", "11", "12", "13"}, {"4", "5", "6", "7"}},
            {{"Africa", "Asia", "Australia", "America"}, {"Nile", "Amazon", "Ganges", "Yangtze"}}
    };

    private String[][] correctAnswers = {
            {"Paris", "Pacific Ocean"},
            {"H2O", "Mercury"},
            {"12", "4"},
            {"Africa", "Nile"}
    };

    private int currentQuestionIndex = 0;
    private int score = 0;
    private int testIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        Intent intent = getIntent();
        testIndex = intent.getIntExtra("testIndex", 0);

        questionText = findViewById(R.id.questionText);
        scoreText = findViewById(R.id.scoreText);
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);

        loadQuestion();

        optionA.setOnClickListener(v -> checkAnswer(optionA.getText().toString()));
        optionB.setOnClickListener(v -> checkAnswer(optionB.getText().toString()));
        optionC.setOnClickListener(v -> checkAnswer(optionC.getText().toString()));
        optionD.setOnClickListener(v -> checkAnswer(optionD.getText().toString()));
    }

    private void loadQuestion() {
        if (currentQuestionIndex < questions[testIndex].length) {
            questionText.setText(questions[testIndex][currentQuestionIndex]);
            optionA.setText(options[testIndex][currentQuestionIndex][0]);
            optionB.setText(options[testIndex][currentQuestionIndex][1]);
            optionC.setText(options[testIndex][currentQuestionIndex][2]);
            optionD.setText(options[testIndex][currentQuestionIndex][3]);
        } else {
            Intent intent = new Intent(TestActivity.this, ResultActivity.class);
            intent.putExtra("score", score);
            intent.putExtra("total", questions[testIndex].length);
            startActivity(intent);
            finish();
        }
    }

    private void checkAnswer(String selectedAnswer) {
        if (selectedAnswer.equals(correctAnswers[testIndex][currentQuestionIndex])) {
            score++;
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Wrong!", Toast.LENGTH_SHORT).show();
        }
        currentQuestionIndex++;
        scoreText.setText("Score: " + score);
        loadQuestion();
    }
}
