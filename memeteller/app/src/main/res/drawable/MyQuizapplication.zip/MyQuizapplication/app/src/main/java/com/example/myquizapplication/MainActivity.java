package com.example.myquizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button test1Button, test2Button, test3Button, test4Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        test1Button = findViewById(R.id.test1Button);
        test2Button = findViewById(R.id.test2Button);
        test3Button = findViewById(R.id.test3Button);
        test4Button = findViewById(R.id.test4Button);

        test1Button.setOnClickListener(view -> startTest(0));
        test2Button.setOnClickListener(view -> startTest(1));
        test3Button.setOnClickListener(view -> startTest(2));
        test4Button.setOnClickListener(view -> startTest(3));
    }

    private void startTest(int testIndex) {
        Intent intent = new Intent(MainActivity.this, TestActivity.class);
        intent.putExtra("testIndex", testIndex);
        startActivity(intent);
    }
}
